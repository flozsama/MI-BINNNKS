# L’héritage de la MI — Crypte Néon Metroidvania

Un metroidvania néon en pixel art qui se joue directement dans le navigateur (un seul fichier HTML, aucune dépendance, aucune installation).

## Jouer

Une fois le dépôt publié avec GitHub Pages : `https://<ton-pseudo>.github.io/<nom-du-depot>/`

Ou en local : ouvre simplement `index.html` dans ton navigateur.

## Commandes

### Clavier / souris
| Action | Touches |
|---|---|
| Se déplacer | `A` `D` ou `←` `→` |
| Sauter | `Espace`, `W` ou `↑` |
| Attaquer | `J`, `X`, `K` ou clic souris (visée à la souris) |
| Dash | `Shift` ou `L` |
| Interagir | `E` |
| Pause | `P` ou `Échap` |
| Stats détaillées | `I` ou `Tab` |
| Plein écran | `F` ou bouton en haut à droite |

### Manette (testé pour l’Ayn Thor, compatible mapping standard / Xbox)
| Action | Bouton |
|---|---|
| Se déplacer | Stick gauche / croix |
| Sauter | `A` |
| Attaquer | `X`, `RB`, `RT` |
| Viser + tirer | Stick droit |
| Dash | `B`, `LB`, `LT` |
| Interagir | `Y` |
| Pause | `Start` |
| Stats | `Select` |
| Plein écran | `R3` |
| Menus / choix | `A`=1, `X`=2, `Y`=3, `LB`=4, `RB`=5, `LT`=6, `B` = retour |

### Tactile
Sticks virtuels affichés automatiquement sur mobile / tablette.

## Publier sur GitHub Pages

1. Crée un dépôt sur GitHub et envoie-y ces fichiers (voir ci-dessous).
2. **Settings → Pages → Build and deployment** : *Deploy from a branch*, branche `main`, dossier `/ (root)`.
3. Après une minute, le jeu est en ligne à l’adresse indiquée dans Settings → Pages.

```bash
git init
git add .
git commit -m "Version 91"
git branch -M main
git remote add origin https://github.com/<ton-pseudo>/<nom-du-depot>.git
git push -u origin main
```

## Notes

- Le jeu est un fichier unique (`index.html`) : sprites et sons sont intégrés.
- La sauvegarde utilise le stockage du navigateur ; elle est propre à chaque appareil et à chaque adresse.
